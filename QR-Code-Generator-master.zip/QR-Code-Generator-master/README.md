# QR-Code-Generator
QR Code Generator and Scanner built in Java using Libraries for Eclipse and Netbeans platform
